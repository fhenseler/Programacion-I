# Clase 15

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Punteros.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=qVW7UfAB7Dk&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=15

### Ejercicio
#### Objetivo:

   Escribir 4 funciones que reciban un array de numeros int y su tama�o, e impriman los numeros por pantalla.

   * 1era funcion: Recibe el array como vector y accede a los datos utilizando notaci�n vectorial ([])

   * 2da funcion: Recibe el array como vector y accede a los datos utilizando aritmetica de punteros

   * 3era funcion: Recibe el array como puntero y accede a los datos utilizando notaci�n vectorial ([])

   * 4da funcion: Recibe el array como puntero y accede a los datos utilizando aritmetica de punteros

- Version: 0.1 del 06 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*   Aritmetica de punteros